package com.javacodegeeks.patterns.chainofresponsibility;


/*
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */

public interface Handler {
	
	public void setHandler(Handler handler);
	public void process(File file);
	public String getHandlerName();
}
