package com.javacodegeeks.patterns.observerpattern;


/*
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */

public interface Commentary {

	public void setDesc(String desc);
}
