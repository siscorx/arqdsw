package com.javacodegeeks.patterns.observerpattern;


/*
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */

public interface Subject {
	
	public void subscribeObserver(Observer observer);
	public void unSubscribeObserver(Observer observer);
	public void notifyObservers();
	public String subjectDetails();
}
