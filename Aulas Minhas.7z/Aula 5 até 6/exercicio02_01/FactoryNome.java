package exercicio02_01;


public interface FactoryNome {
	
	Nome getNome(String nome);
	void listarNomes();
}
