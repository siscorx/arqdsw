package exercicio02_01;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */

public class TesteNomes {
		
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		FactoryNome factNS = new FactoryNomeSobrenome();
		FactoryNome factSN = new FactorySobrenomeNome();
		
		String danc = "Cunha, Daniel";
		String dancun= "Daniel Cunha";
		String dancunha = "Cunha, Daniel";
		
		Nome nomeScott = factSN.getNome(danc);
		Nome nomeJames = factNS.getNome(dancun);
		Nome nomePatrick = factSN.getNome(dancunha);
		
		factNS.listarNomes();
		factSN.listarNomes();		
	}
}
