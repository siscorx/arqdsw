package exercicio07_01;


public class Duplicado extends Padrao {

	@Override
	String transforma(String s) {
		return s + s;
	}
}
