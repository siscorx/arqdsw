package exercicio07_01;


public class Minusculo extends Padrao {

	@Override
	String transforma(String s) {
		return s.toLowerCase();
	}
}
