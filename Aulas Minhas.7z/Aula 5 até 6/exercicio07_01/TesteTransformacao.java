package exercicio07_01;

/* 
 * Nome: Daniel Cunha
 * RA: 2014019900
 * 
 */


public class TesteTransformacao {
	
	public static void main(String[] args) {
		
		Padrao transf = new Maiusculo();
		
		transf.processo();
		
		transf = new Minusculo();
		
		transf.processo();
		
		transf = new Duplicado();
		
		transf.processo();
		
		transf = new Invertido();
		
		transf.processo();		
	}
}
