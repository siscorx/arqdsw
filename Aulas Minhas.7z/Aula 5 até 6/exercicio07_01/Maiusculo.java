package exercicio07_01;

public class Maiusculo extends Padrao {

	@Override
	String transforma(String s) {
		return s.toUpperCase();
	}
}
