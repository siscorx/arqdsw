package exercicio03_01;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */


public class TesteIncremental {
	
	public static void main(String[] args) {
		for (int i = 0; i < 20; i++) {
			Incremental inc = Incremental.getInstanceOff();
			inc.incrementa();
			System.out.println(inc);
		}
	}	
}
