package exercicio02_03;


public abstract class Log {
	
	abstract void efetuar(int[] numeros);
}
