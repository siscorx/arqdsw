package exercicio02_03;

/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */


public class TesteLog {
	
	public static void main(String[] args) {
		
		LogFactory logfact = new LogFactory();
		
		Log log = logfact.getLog("Arquivo");
		log.efetuar(numeros);
		
		log = logfact.getLog("Console");
		log.efetuar(numeros);
		
	}

}
