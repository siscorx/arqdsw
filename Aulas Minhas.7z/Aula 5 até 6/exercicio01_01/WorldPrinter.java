package exercicio01_01;

public interface WorldPrinter {

	void print();
}
