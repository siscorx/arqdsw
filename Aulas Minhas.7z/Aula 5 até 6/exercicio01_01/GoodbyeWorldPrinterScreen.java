package exercicio01_01;

public class GoodbyeWorldPrinterScreen implements WorldPrinter {

	@Override
	public void print() {
		
		System.out.println("Bye Bye, World!");
	}

}
