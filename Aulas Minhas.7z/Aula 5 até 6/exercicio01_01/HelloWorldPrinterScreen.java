package exercicio01_01;

public class HelloWorldPrinterScreen implements WorldPrinter {

	@Override
	public void print() {
		
		System.out.println("Hello, World!");
	}

}
