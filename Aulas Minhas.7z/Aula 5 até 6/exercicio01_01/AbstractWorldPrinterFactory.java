package exercicio01_01;

public interface AbstractWorldPrinterFactory {

	WorldPrinter getPrinterInstance(String printerType);
}
