package exercicio05;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 */


public class TesteFacade {
	
	public static void main(String[] args) {
		
		IOFacade iof = new IOFacade();
		byte[] byteArray = {10, 20, 30, 40, 50, 60, 70, 80};
		String[] texto = {"Primeira linha", "Segunda linha"};
		Cliente cliente = new Cliente();
		
		System.out.println("Gravando arquivo texto.");
		iof.gravarArquivoTexto("TesteTexto.txt", texto);
		System.out.println("Lendo arquivo texto.");
		iof.lerArquivoBinario("TesteTexto.txt");
		
		System.out.println("Gravando arquivo binary.");
		iof.gravarArquivoBinario("Teste Binary", byteArray);
		System.out.println("Lendo arquivo binary.");
		iof.lerArquivoBinario("Teste Binary");
		
		cliente.setNome("ClienteTeste");
		System.out.println("Gravando objeto.");
		iof.gravarObjeto("TesteObjeto", cliente);
		System.out.println("Lendo objeto.");
		iof.lerObjeto("TesteObjeto");		
	}
}
