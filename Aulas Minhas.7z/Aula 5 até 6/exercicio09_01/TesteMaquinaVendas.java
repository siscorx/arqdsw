package exercicio09_01;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */



public class TesteMaquinaVendas {
	
	public static void main(String[] args) {
		
		EntradasChain chain001cent = new Entrada001Centavos();
		EntradasChain chain005cent = new Entrada005Centavos();
		EntradasChain chain010cent = new Entrada010Centavos();
		EntradasChain chain025cent = new Entrada025Centavos();
		EntradasChain chain050cent = new Entrada050Centavos();
		EntradasChain chain100cent = new Entrada100Centavos();
		
		chain1cent.setNextChain(chain5cent);
		chain5cent.setNextChain(chain10cent);
		chain10cent.setNextChain(chain25cent);
		chain25cent.setNextChain(chain50cent);
		chain50cent.setNextChain(chain1real);
		
		Produto bebida = new Produto("Coca-Cola", 1.00);
		Produto salgadin = new Produto("Rufles", 2.50);
		
		Moeda m001c = new Moeda(0.01);
		Moeda m005c = new Moeda(0.05);
		Moeda m010c = new Moeda(0.10);
		Moeda m025c = new Moeda(0.25);
		Moeda m050c = new Moeda(0.50);
		Moeda m100c = new Moeda(1.00);
		
		chain1cent.calcula(m005c, bebida);
		chain1cent.calcula(m010c, bebida);
		chain1cent.calcula(m025c, bebida);
		chain1cent.calcula(m025c, bebida);
		chain1cent.calcula(m100c, bebida);
		
		chain1cent.calcula(m001c, salgadin);
		chain1cent.calcula(m050c, salgadin);
		chain1cent.calcula(m100c, salgadin);
		chain1cent.calcula(m050c, salgadin);
		chain1cent.calcula(m025c, salgadin);
		chain1cent.calcula(m025c, salgadin);	
	}
}
