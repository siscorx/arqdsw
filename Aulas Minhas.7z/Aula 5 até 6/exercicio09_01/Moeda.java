package exercicio09_01;


public class Moeda {
	
	private double valor;
	
	public Moeda(double valor) {
		this.setValor(valor);
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
}
