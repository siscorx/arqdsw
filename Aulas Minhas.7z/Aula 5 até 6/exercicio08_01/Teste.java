package exercicio08_01;

import java.util.ArrayList;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */


public class Teste {

	public static void main(String[] args) {
		
		NoticiaAssina noticiario = new NoticiaAssina(new ArrayList<ConsomeNoticia>());
		
		Consumidor con1 = new Consumidor(noticiario,"Daniel");
		Consumidor con2 = new Consumidor(noticiario,"Fabio");
		Consumidor con3 = new Consumidor(noticiario,"Jos�");
		
		con1.assinar();
		con2.assinar();
		Noticia noticia1 = new Noticia();
		noticia1.setTextoNoticia("D�lar cresce pacas.");
		noticia1.setDia(24);
		noticia1.setMes(10);
		noticia1.setTopico("Economia");
		noticiario.setNoticia(noticia1);		
		con1.cancelar();
		
		Noticia noticia2 = new Noticia();
		noticia2.setTextoNoticia("Bolsonaro 2018.");
		noticia2.setDia(25);
		noticia2.setMes(10);
		noticia2.setTopico("Politica");
		
		noticiario.setNoticia(noticia2);
		con3.assinar();
		con1.assinar();
		
		
		Noticia noticia3 = new Noticia();
		noticia3.setTextoNoticia("Novo celular foi criado.");
		noticia3.setDia(20);
		noticia3.setMes(9);
		noticia3.setTopico("Ci�ncia");
		
		noticiario.setNoticia(noticia3);
		
		
	}
	
	

}
