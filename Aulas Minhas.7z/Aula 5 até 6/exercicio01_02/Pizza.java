package exercicio01_02;

public interface Pizza {

	String fazer();
}
