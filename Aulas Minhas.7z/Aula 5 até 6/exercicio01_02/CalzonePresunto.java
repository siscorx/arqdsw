package exercicio01_02;

public class CalzonePresunto implements Pizza {

	@Override
	public String fazer() {
		return "Calzone presunto (queiijo, calabresa e tomate)";
	}

}
