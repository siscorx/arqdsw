package exercicio01_02;

public interface AbstractPizzaria {
	Pizza getFactory(DiaSemana dia);
}
