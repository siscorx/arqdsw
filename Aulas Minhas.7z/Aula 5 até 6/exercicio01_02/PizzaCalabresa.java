package exercicio01_02;

public class PizzaCalabresa implements Pizza {

	@Override
	public String fazer() {
		return "Pizza calabresa (queijo, calabresa e tomate)";
	}

}
