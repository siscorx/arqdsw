package exercicio01_02;

public class CalzoneCalabresa implements Pizza {

	@Override
	public String fazer() {
		return "Calzone calabresa (queiijo, calabresa e tomate)";
	}

}
