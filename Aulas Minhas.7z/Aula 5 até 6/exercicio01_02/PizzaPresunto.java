package exercicio01_02;

public class PizzaPresunto implements Pizza {

	@Override
	public String fazer() {
		return "Pizza presunto (queiijo, calabresa e tomate)";
	}

}
