package exercicio06_02;

public interface Sort {
	
	int[] sort(int v[]);
}
