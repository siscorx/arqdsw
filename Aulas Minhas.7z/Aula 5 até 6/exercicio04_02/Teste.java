package exercicio04_02;


/*
 * Nome: Daniel Cunha
 * RA: 201409900
 */

public class Teste{

	public static void main(String[] args) {
		SomadorEsperado somador = new SomadorAdapter();
		Cliente cliente = new Cliente(somador);
		cliente.executar();
	}
}
