package exercicio04_02;

public interface SomadorEsperado {
	int somaVetor(int[] vetor);
}
