package exercicio08_02;



public abstract class Noticiario {
	
	public abstract void notificaNoticia(String textoNoticia, int dia,
			int mes, String topico);
}
