package exercicio08_02;

public interface ConsomeNoticia {
	public void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
}