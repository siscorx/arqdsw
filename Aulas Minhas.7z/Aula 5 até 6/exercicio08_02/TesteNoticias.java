package exercicio08_02;


/* 
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */
 

public class TesteNoticias {
	
	public static void main(String[] args) {
		
		NoticiarioAssina not = new NoticiarioAssina();
		ConsomeNoticia pub = new Publicador();
		Agregador agrTop = new AgregadorTopico("Programa��o");
		Agregador agrMes = new AgregadorMes();
		
		not.adicionaConsumidor(pub);
		not.adicionaConsumidor(agrTop);
		not.adicionaConsumidor(agrMes);
		
		agrTop.adicionaConsumidor(pub);
		agrMes.adicionaConsumidor(pub);		
		
		not.notificaNoticia("Not 1.", 6, 5, "Programa��o");
		not.notificaNoticia("Not 2.", 31, 5, "Programa��o");
		not.notificaNoticia("Not 3", 20, 6, "Programa��o");
	}
}
