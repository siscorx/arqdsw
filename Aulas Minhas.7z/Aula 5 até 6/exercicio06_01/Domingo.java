package exercicio06_01;

public class Domingo implements DiaDaSemana {

	@Override
	public String dia() {

		return "Domingo";
	}
}
