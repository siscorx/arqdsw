package exercicio06_01;

public class Segunda implements DiaDaSemana {

	@Override
	public String dia() {
	
		return "Segunda-Feira";
	}

}
