package exercicio06_01;

public class Terca implements DiaDaSemana {

	@Override
	public String dia() {
	
		return "Ter�a-Feira";
	}

}
