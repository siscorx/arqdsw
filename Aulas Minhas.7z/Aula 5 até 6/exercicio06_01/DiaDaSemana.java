package exercicio06_01;

public interface DiaDaSemana {
	public String dia();
}
