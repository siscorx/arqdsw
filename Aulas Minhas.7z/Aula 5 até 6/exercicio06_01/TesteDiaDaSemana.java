package exercicio06_01;

/* 
 * Nome: Daniel Cunha
 * RA: 816114946
 */

public class TesteDiaDaSemana {

	public static void main(String[] args) {
		Semana semana = new Semana(new Quarta());
		semana.imprimeDia();
	}
}
