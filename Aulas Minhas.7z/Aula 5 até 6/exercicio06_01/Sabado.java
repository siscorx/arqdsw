package exercicio06_01;

public class Sabado implements DiaDaSemana {

	@Override
	public String dia() {

		return "S�b�do";
	}

}
