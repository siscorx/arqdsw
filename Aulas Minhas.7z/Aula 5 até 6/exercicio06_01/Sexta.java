package exercicio06_01;

public class Sexta implements DiaDaSemana {

	@Override
	public String dia() {
	
		return "Sexta-Feira";
	}

}
