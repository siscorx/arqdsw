package exercicio06_01;

public class Quinta implements DiaDaSemana {

	@Override
	public String dia() {

		return "Quinta-feira";
	}

}
