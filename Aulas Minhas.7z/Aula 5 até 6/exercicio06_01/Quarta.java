package exercicio06_01;

public class Quarta implements DiaDaSemana {

	@Override
	public String dia() {

		return "Quarta-feira";
	}

}
