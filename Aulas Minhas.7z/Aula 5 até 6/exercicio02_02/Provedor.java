package exercicio02_02;


public abstract class Provedor {
	
	abstract void exibir();
}
