package exercicio02_02;


/*
 * Nome: Daniel Cunha
 * RA: 201409900
 * 
 */


public class TesteProvedores {	
	public static void main(String[] args) {
		
		FactoryProvedor provFact = new FactoryProvedor();
		
		// Confidencial
		Provedor provedor = provFact.getProvedor("patterns");
		provedor.exibir();
		
		// Public
		provedor = provFact.getProvedor();
		provedor.exibir();		
	}
}
